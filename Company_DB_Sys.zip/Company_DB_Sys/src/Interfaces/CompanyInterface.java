package Interfaces;

public interface CompanyInterface {

    public double calculateExpenditure();
}
